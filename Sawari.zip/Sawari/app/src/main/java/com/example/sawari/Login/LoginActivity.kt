package com.example.sawari.Login

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.sawari.MainActivity
import com.example.sawari.databinding.ActivityLoginBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding
    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        if (auth.currentUser != null) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }

        binding.buttonNext.isEnabled = false

        binding.editTextPhoneNumber.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {}

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val phoneNumber = s.toString()
                if (phoneNumber.length == 10) {
                    binding.buttonNext.isEnabled = true
                    binding.buttonNext.setBackgroundColor(Color.BLUE)
                } else {
                    binding.buttonNext.isEnabled = false
                    binding.buttonNext.setBackgroundColor(Color.GRAY)
                }
            }
        })

        binding.buttonNext.setOnClickListener {
            val phoneNumber = binding.editTextPhoneNumber.text.toString()
            if (phoneNumber.length != 10) {
                Toast.makeText(this, "Please Enter a 10-digit Number", Toast.LENGTH_SHORT).show()
            } else {
                savePhoneNumber(phoneNumber)
                val intent = Intent(this, OTPActivity::class.java)
                intent.putExtra("number", phoneNumber)
                startActivity(intent)
            }
        }
    }

    private fun savePhoneNumber(phoneNumber: String) {
        val uid = auth.currentUser?.uid
        if (uid != null) {
            val user = hashMapOf("phoneNumber" to phoneNumber)
            db.collection("users").document(uid).set(user)
                .addOnSuccessListener {
                    Toast.makeText(this, "Phone number saved", Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener { e ->
                    Toast.makeText(this, "Failed to save phone number: ${e.message}", Toast.LENGTH_SHORT).show()
                }
        } else {
            Toast.makeText(this, "User not authenticated", Toast.LENGTH_SHORT).show()
        }
    }
}
